package com.helb.eatBelgium.model;

public class Category {
    private String nomCategory;

    public Category() {
    }

    public Category(String nomCategory) {
        this.nomCategory = nomCategory;
    }

    public String getNomCategory() {
        return nomCategory;
    }

    public void setNomCategory(String nomCategory) {
        this.nomCategory = nomCategory;
    }
}

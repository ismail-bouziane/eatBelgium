package com.helb.eatBelgium.Controlers.Fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.helb.eatBelgium.R;
import com.helb.eatBelgium.Views.CategoriesAdapter;
import com.helb.eatBelgium.model.Category;

import java.util.List;




public class PlatsFragment extends Fragment {

    private List<Category> listCategory;
    private CategoriesAdapter categoriesAdapter;
    private RecyclerView recyclerView;
    private LinearLayoutManager linearLayoutManager;
    private FirebaseRecyclerAdapter adapter;


    public static PlatsFragment newInstance() {
        return (new PlatsFragment());
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_plats, container, false);
        recyclerView = findViewById(R.id.list_categories);
    }
}
